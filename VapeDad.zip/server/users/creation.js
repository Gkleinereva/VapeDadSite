exports.CreateUser = function(email, password) {
	
	var fs = require('fs');

	//require crypto module so that we can use its functions to generate salt and hash
	var crypto = require('crypto');

	let userJson = {};

	userJson.email = email;
	userJson.salt = crypto.randomBytes(16).toString('hex');
	userJson.hash = crypto.pbkdf2Sync(password, userJson.salt, 1000, 64, 'sha512').toString('hex');

	console.log(userJson);

	fs.writeFile(
		"bin.js",
		JSON.stringify(userJson),
		function(err) {
			console.log(err);
		}
	);

}

exports.GenSecret = function() {
	var crypto = require('crypto');
	console.log(crypto.randomBytes(16).toString('hex'));
}

// Can run from users/ with 'node Creation.js CreateUser <username> <password>
var runnable = require('make-runnable');