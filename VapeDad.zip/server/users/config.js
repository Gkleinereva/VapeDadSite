var config = {
	SECRET: "9915da437b036d88e37ec67179776fce"
};

module.exports = config;